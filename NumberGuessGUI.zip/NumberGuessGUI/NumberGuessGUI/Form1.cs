using System.Windows.Forms;

namespace NumberGuessGUI
{
    public partial class Form1 : Form
    {
        int number;
        int tries;
        int guessconvert;
        String guess = " ";

        public Form1()
        {
            InitializeComponent();
            NewNumber();
        }
        private void NewNumber()
        {
            number = new Random().Next(1, 101);
            tries = 1;
        }
        private void CheckNumber()
        {
            try
            {
                guess = textBox1.Text;
                guessconvert = Convert.ToInt32(guess);



                if (guessconvert > 100 || guessconvert < 1)
                {
                    label2.Visible = true;
                    label2.Text = ("Your number isn't between 1 and 100, try again");
                    GuessList.Items.Add("" + guessconvert + "");
                    tries++;
                }
                else
                {
                    if (guessconvert < number)
                    {
                        label2.Visible = true;
                        label2.Text = ("try a bigger number");
                        GuessList.Items.Add("" + guessconvert + " bigger");
                        tries++;
                    }

                    if (guessconvert > number)
                    {
                        label2.Visible = true;
                        label2.Text = ("Try a smaller number");
                        GuessList.Items.Add("" + guessconvert + " smaller");
                        tries++;
                    }

                    if (guessconvert == number)
                    {
                        String x = "";
                        if (tries == 1)
                            x = "time";
                        if (tries > 1)
                            x = "times";
                        if(guessconvert == number)
                            label2.Visible=true;
                            label2.Text = ("you did it! You tried " + tries + " " + x + ". You can try again.");
                        
                    }
                }
            }
            catch
            {
                label2.Visible = true;
                label2.Text = ("Your input ins't a number try again");
                GuessList.Items.Add("" + guessconvert + " no number");
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CheckNumber();
            textBox1.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void textBox1_KeyDown(object sender, KeyEventArgs e) 
        { 
            if (e.KeyCode == Keys.Enter) 
                button1.PerformClick();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            NewNumber();
            GuessList.Items.Clear();
            textBox1.Clear();
        }
    }
}